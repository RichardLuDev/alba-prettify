[Alba Prettify Extension](https://chrome.google.com/webstore/detail/alba-prettify/bclfehbjcncmedmofkfadkaobjjjmcme)
=============

[Discussion Group](https://groups.google.com/forum/#!forum/alba-prettify)

A Chrome extension that improves Alba's territory printing output.

I try to follow the [Google Javascript Style Guide](https://google-styleguide.googlecode.com/svn/trunk/javascriptguide.xml).